# dg

playing with GitLab CI/CD.

