package com.mycompany.app;

import javax.crypto.Cipher;
import java.lang.Exception;

public class App2
{
    private void bar1(String s) throws Exception
    {
        final Cipher c1 = Cipher.getInstance(s);
        c1.doFinal();
    }
    
    private void foo() throws Exception {
        bar1("DES"); // this should create a warning
    } 
}
