#!/bin/sh

red=$'\e[1;31m'
grn=$'\e[1;32m'
yel=$'\e[1;33m'
blu=$'\e[1;34m'
mag=$'\e[1;35m'
cyn=$'\e[1;36m'
end=$'\e[0m'

export AWS_DEFAULT_OUTPUT="text"

script_dir=$(dirname $0)

PYTHON_VERSION=3.8
amazon-linux-extras enable python${PYTHON_VERSION} && yum install -y python${PYTHON_VERSION}
update-alternatives --install /usr/bin/python python /usr/bin/python${PYTHON_VERSION} 1

aws configure add-model --service-model "file://${script_dir}/codeguru-reviewer-betav2.json" --service-name codeguru-reviewer-betav2
cp "${script_dir}/codeguru-reviewer-betav2.waiters-2.json" ~/.aws/models/codeguru-reviewer-betav2/codeguru-reviewer-betav2.waiters-2.json
cp "${script_dir}/codeguru-reviewer-betav2.paginators.json" ~/.aws/models/codeguru-reviewer-betav2/codeguru-reviewer-betav2.paginators.json

python -m pip install -r "${script_dir}/requirements.txt"
python -m pip install jq

die () {
    echo >&2 "\n${red}Exiting with ERROR: $@${end}"
    exit 1
}

die_if_failed () {
    [ ! $? -eq 0 ] && die "Last operation failed."
}

printf "\n${grn}AWS CodeGuru Reviewer Scanner${end}\n"

# Because they are critical to operation, be verbose about whether and where source_path and build_root were or were not found
if [ -n "$source_path" ]; then echo "Detected Java Source dir variable, source_path is set to $source_path"; fi
if [ -z "$source_path" ] && [ -n "$1" ]; then source_path=$1; echo "Detected Java Source dir parameter (1st), source_path is now set to $source_path"; fi
if [ -z "$source_path" ] && [ -d src/main/java ]; then source_path=src/main/java; echo "Detected Java Source dir is present, source_path is now set to $source_path"; fi
if [ -z "$source_path" ]; then die "Source root not found or is not a directory."; fi

if [ -n "$build_path" ] && [ -d "$build_path" ]; then 
    echo "Detected Build dir variable, build_root is set to $build_path";
elif [ -z "$build_path" ] && [ -n "$2" ] && [ -d "$2" ]; then 
    build_path=$2; echo "Detected Build dir parameter (2nd), build_root is now set to $build_path";
elif [ -z "$build_root" ] && [ -d target ]; then 
    build_path=target; echo "Detected Java Build dir is present, build_root is now set to $build_path";
else 
   build_path=""; 
fi

if [ -n "$aws_region" ]; then echo "Detected aws_region variable, aws_region is set to $aws_region"; fi
if [ -z "$aws_region" ] && [ -n "$AWS_DEFAULT_REGION" ]; then aws_region=$AWS_DEFAULT_REGION; echo "Detected GitLab, aws_region is now set to $aws_region"; fi
if [ -z "$aws_region" ] && [ -z "$AWS_DEFAULT_REGION" ]; then aws_region=""; fi

if [ "$CI_PIPELINE_SOURCE" == "merge_request_event" ]; then before_commit_sha=$CI_MERGE_REQUEST_DIFF_BASE_SHA; event_id=$CI_MERGE_REQUEST_ID; fi
if [ "$CI_PIPELINE_SOURCE" == "push" ]; then before_commit_sha=$CI_COMMIT_BEFORE_SHA; event_id=$CI_JOB_ID; fi
if [ "$CI_PIPELINE_SOURCE" == "schedule" ]; then after_commit_sha=""; event_id=$CI_JOB_ID; else after_commit_sha=$CI_COMMIT_SHA; fi

python "${script_dir}/src/codeguru/command.py" -v \
  --name "$CI_PROJECT_NAME" \
  --source_path  "$source_path" \
  --build_path "$build_path" \
  --kms_key_id "$kms_key_id" \
  --aws_region "$aws_region" \
  --client_id "GitLab_v1" \
  --event_id "$event_id" \
  --before_commit_sha "$before_commit_sha" \
  --after_commit_sha "$after_commit_sha" \
  --event_name "$CI_PIPELINE_SOURCE" \
  --s3_bucket "$s3_bucket" \
  --output_format "SAST"
  
if [ ! -f codeguru-results.sast.json ] || [ ! -f codeguru-code-quality-report.json ]; then die_if_failed; fi
  
printf "\n${grn}AWS CodeGuru Reviewer Scanner - end marker${end}\n"
