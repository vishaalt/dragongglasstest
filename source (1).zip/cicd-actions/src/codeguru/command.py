import logging, sys
import argparse
import boto3
import uuid
import json
import os
import jq
import zipfile
from core.reviewer import Reviewer
from utils import s3, archiver, region_helper
from boto3.s3.transfer import TransferConfig
from utils.cli_helper import ReadableDirectory, kms_key_id_regex_type
from core.models import S3RepositoryAssociation, RequestMetadata, CodeReviewRequest
#from utils.formatter import DEFAULT_OUTPUT_FORMAT, OUTPUT_FORMATS

MB = 1024 ** 2

log = logging.getLogger('codeguru-reviewer')
SUPPORTED_EVENTS = ['push', 'pull_request', 'schedule', 'merge_request_event', 'workflow_dispatch']
SUPPORTED_EVENT_STATES = ['opened', 'closed']
OUTPUT_FORMATS = ['SARIF', 'SAST', 'JENKINS']

def build_code_review_request(s3_association, args):

    event_type = {}

    if args.event_name:
        event_type['Name'] = args.event_name
    if args.event_state:
        event_type['State'] = args.event_state

    zipf_source = zipfile.ZipFile('source.zip', 'w', zipfile.ZIP_DEFLATED)
    archiver.zipdir(args.src_root, zipf_source)
    log.info(f"src_root: {args.src_root}")
    zipf_source.close()

    s3_key_prefix = uuid.uuid4()
    s3 = boto3.resource('s3', region_name=region_helper.get_region())
    bucket = s3.Bucket(s3_association.s3_bucket)
    config = TransferConfig(multipart_threshold=10*MB, max_concurrency=5) # Set the desired multipart threshold value (5MB)
    # s3_archive_path = f'{s3_key_prefix}/{os.path.basename(archive_path)}'
    bucket.upload_file('source.zip', str(s3_key_prefix) + "/" + "source.zip", Config=config)

    if args.build_root:
        zipf_build = zipfile.ZipFile('build.zip', 'w', zipfile.ZIP_DEFLATED)
        archiver.zipdir(args.build_root, zipf_build, "(.*jar$)")
        log.info(f"build_root: {args.build_root}")
        zipf_build.close()
        bucket.upload_file('build.zip', str(s3_key_prefix) + "/" + "build.zip", Config=config)

        return CodeReviewRequest(
            s3_association = s3_association,
            src_s3key = str(s3_key_prefix) + "/source.zip",
            build_s3key = str(s3_key_prefix) + "/build.zip",
            before_commit = args.before_commit_sha, after_commit = args.after_commit_sha, merge_commit = args.merge_commit_sha,
            source_branch = args.source_branch, destination_branch = args.destination_branch,
            request_context = RequestMetadata(request_id=args.event_id, requester=args.agent, event_type=event_type)
        )

    # logging.info(f"S3 Upload of {archive_path} completed")
    # logging.info(f"Archive {archive_path} removed")
    # return s3_archive_path

    # src_archive = archiver.zip(src=args.src_root, archive_name="source")
    # s3_key_prefix = uuid.uuid4()
    # src_s3key, build_s3key = s3.upload_archive(s3_bucket=s3_association.s3_bucket, s3_prefix=s3_key_prefix, archive_path=src_archive), None
    # if args.build_root:
    #     build_archive = archiver.zip(src=args.build_root, archive_name="build", file_regex="(.*jar$)", junk_paths=True)  #take regex as argument
    #     build_s3key =  s3.upload_archive(s3_bucket=s3_association.s3_bucket, s3_prefix=s3_key_prefix, archive_path=build_archive)

    return CodeReviewRequest(
        s3_association = s3_association,
        src_s3key = str(s3_key_prefix) + "/source.zip",
        before_commit = args.before_commit_sha, after_commit = args.after_commit_sha, merge_commit = args.merge_commit_sha,
        source_branch = args.source_branch, destination_branch = args.destination_branch,
        request_context = RequestMetadata(request_id=args.event_id, requester=args.agent, event_type=event_type)
    )

def validate_commits(args):
    if (args.before_commit_sha and not args.after_commit_sha) or (not args.before_commit_sha and args.after_commit_sha):
         log.info("Both Before and After Commit SHAs are required")
         sys.exit(-1)

def validate_event(args):
    if args.event_name not in SUPPORTED_EVENTS:
         log.warn(f"Event Trigger: [{args.event_name}] is not supported at the moment.")
         sys.exit(-1)

    if args.output_format not in OUTPUT_FORMATS:
         log.warn(f"Ouptut format: [{args.output_format}] is not supported.")
         sys.exit(-1)
    # if args.event_state not in SUPPORTED_EVENT_STATES:
    #      log.info("Event State: {args.event_state} is not supported at the moment.")
    #      sys.exit(-1)

def convert_to_sarif(results_json):
    jq_data = '{version: "2.1.0", "$schema": "http://json.schemastore.org/sarif-2.1.0-rtm.4", runs:[{tool:{driver:{name: "CodeGuru Reviewer Security Scanner", informationUri:"https://docs.aws.amazon.com/codeguru/latest/reviewer-ug/how-codeguru-reviewer-works.html", rules:[.RecommendationSummaries[] | select (.FilePath != ".") | {id: .RecommendationId, help: {text: .Description, markdown: .Description}}]}}, results:[.RecommendationSummaries[] | select (.FilePath != ".") | {ruleId: .RecommendationId, level:"warning", locations:[{physicalLocation:{artifactLocation:{uri: .FilePath}, region:{startLine: .StartLine, endLine: .EndLine}}}], message: {text: .Description | split(".")[0]}}]}] }';
    results = jq.compile(jq_data).input(results_json).first()

    with open('codeguru-results.sarif.json', 'w+') as sarif_results:
        json.dump(results, sarif_results, indent=4)
    log.info(f"SARIF persisted to {os.path.abspath('codeguru-results.sarif.json')}")

def convert_to_sast(results_json):
    jq_data_sast = '{version: "3.0", scan:{type:"sast", status: "success", scanner:{id:"codeguru-reviewer", name: "CodeGuru Reviewer Security Scanner", url:"https://docs.aws.amazon.com/codeguru/latest/reviewer-ug/how-codeguru-reviewer-works.html"}, vendor:{name:"AWS CodeGuru Reviewer"}}, vulnerabilities:[.RecommendationSummaries[] | select(.RecommendationId | contains("security")) | select (.FilePath != ".") | {id: .RecommendationId, category: "sast", severity:"Critical", confidence: "High", description: .Description, message: .Description | split(".")[0], identifiers:[{type: .RecommendationId | split("-")[0], value: .RecommendationId | split("-")[1], url: .Description | match(".*\\\\[(.*)\\\\]\\\\((https?.*)\\\\)").captures[1].string, name: .RecommendationId }], location:{file:.FilePath, start_line: .StartLine, end_line: .EndLine},"scanner":{ "id":"codeguru-reviewer", "name":"CodeGuru Reviewer Security Scanner" }}] }';
    results_sast = jq.compile(jq_data_sast).input(results_json).first()

    with open('codeguru-results.sast.json', 'w+') as sast_results:
        json.dump(results_sast, sast_results, indent=4)
    log.info(f"SAST persisted to {os.path.abspath('codeguru-results.sast.json')}")
             
    jq_data_codequality = '[ .RecommendationSummaries[] | select(.RecommendationId | contains("security") | not) | { description: .Description, fingerprint: .RecommendationId, severity: "critical", location: { path:.FilePath, lines: { begin: .StartLine, end: .EndLine} } } ]';
    results_codequality = jq.compile(jq_data_codequality).input(results_json).first()
             
    with open('codeguru-code-quality-report.json', 'w+') as codequality_results:
        json.dump(results_codequality, codequality_results, indent=4)
    log.info(f"CodeQuality persisted to {os.path.abspath('codeguru-code-quality-report.json')}")

def convert_to_jenkins(results_json):
    jq_data = '.RecommendationSummaries[] | select (.FilePath != ".") | {fileName: .FilePath, lineStart: .StartLine, lineEnd: .EndLine, reference: .RecommendationId, message: .Description | split(".")[0], description: .Description, severity: "HIGH" }';
    results = jq.compile(jq_data).input(results_json).first()

    with open('codeguru-results.jenkins-json.log', 'w+') as sarif_results:
        json.dump(results, sarif_results, indent=4)
    log.info(f"JENKINS output persisted to {os.path.abspath('codeguru-results.jenkins-json.log')}")

def transform_repo_name(name):
    input_repo_name = name
    repo_name = input_repo_name.replace("/", "-")
    return repo_name

def main(args):
    logging.basicConfig(format='%(asctime)s %(levelname)s %(message)s')
    log.setLevel(args.loglevel or logging.INFO)
    log.debug("Received following arguments - %s", args)
    region_helper.configure_aws_region(args.aws_region)
    validate_event(args)
    validate_commits(args)

    reviewer = Reviewer(args.loglevel, args.client_id)
    s3_repo_association = reviewer.create_or_get_s3_association(transform_repo_name(args.name), args.s3_bucket, args.kms_key_id)
    recommendations = reviewer.trigger_code_review(build_code_review_request(s3_repo_association, args))
    log.info(f"Fetched {len(recommendations.get('RecommendationSummaries', [])) - 1} recommendations for the code review job: {args.name}")

    if args.output_format == "SARIF":
        convert_to_sarif(recommendations)
    elif args.output_format == "SAST":
        convert_to_sast(recommendations)
    else:
        convert_to_jenkins(recommendations)

    with open('codeguru-results.json', 'w+') as results_json:
        json.dump(recommendations, results_json, indent=4)
    log.info(f"Recommendations persisted to {os.path.abspath('codeguru-results.json')}")

    log.info(f"Amazon CodeGuru Reviewer job execution completed")


if __name__ == '__main__':
    sys.tracebacklimit=0 #Turn off python tracebacks
    parser = argparse.ArgumentParser()
    parser._optionals.title = 'Expected Arguments'
    # Required Arguments
    parser.add_argument("--name", help="[REQUIRED] A name for the job. Could be the name of a Github/GitLab/BitBucket Repository", required=True)
    parser.add_argument("--source_path", help="[REQUIRED] Path containing source code e.g. src/main/java for java source files. Note that source code files under this path must be readable", dest='src_root', required=True)
    # Optional Arguments
    parser.add_argument("--build_path", help="Path containing build artifacts e.g. results of running `mvn package` or `gradle build`. Note that build artifacts under this path must be readable.", dest='build_root')
    parser.add_argument("--kms_key_id", default="", help="AWS KMS Key ID to use for encrypting source code and build artifacts. If not specified, an Amazon-owned KMS key would be used.", type=kms_key_id_regex_type)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("-v", "--verbose", help="Enable Verbose logging", nargs='?', const=logging.DEBUG, dest='loglevel', default=logging.INFO)
    group.add_argument("-q", "--quiet", help="Disable Verbose Logging", nargs='?', const=logging.WARN, dest='loglevel', default=logging.INFO)
    parser.add_argument("--aws_region", help="Provide an AWS Region (e.g. us-west-2) for use. Please note CodeGuru Reviewer is not available in all aws regions")
    parser.add_argument("--client_id", default="Github-Actions", help="Unique identifier referring to a specific client version e.g. Github-actions@v2")
    parser.add_argument("--event_id", help="An identifier for the event that triggered CodeGuru Reviewer Analysis")
    parser.add_argument("--agent", help="An agent typically developers/maintainers who author changes in a source code repository")
    parser.add_argument("--before_commit_sha", help="SHA of previous commit in the source code repository existed before an event")
    parser.add_argument("--after_commit_sha", help="SHA of next commit to be committed to source code repository after an event")
    parser.add_argument("--merge_commit_sha", help="SHA of a commit that's the merge base for before and after commits in a pull request")
    parser.add_argument("--source_branch", help="Source Branch")
    parser.add_argument("--destination_branch", help="Destination branch")
    parser.add_argument("--event_name", help="Supported Events: push, pull_request, merge_request_event, schedule, workflow_dispatch")
    parser.add_argument("--event_state", help="e.g. Pull/Merge Request states: (opened, closed)")
    parser.add_argument("--s3_bucket", help="S3 Bucket Name which will be associated for this repository association. Bucket Name must have a prefix of codeguru-reviewer-")
    parser.add_argument("--output_format", help="Expected format for the results (e.g SARIF, SAST, JENKINS)")
    args = parser.parse_args()
    main(args)
