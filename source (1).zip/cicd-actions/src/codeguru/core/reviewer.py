import boto3
import uuid
import logging
import os
import time
from botocore.exceptions import WaiterError
from botocore.config import Config
from utils.region_helper import get_region
from core.models import S3RepositoryAssociation, CodeReviewRequest

ENDPOINT_URL = 'https://codeguru-reviewer.{aws_region}.amazonaws.com'
PRE_ENDPOINT_URL = 'https://{aws_region}.preprod.fe-service.guru.aws.a2z.com'

def reviewer_config(region):
    return Config(
        region_name = region,
        retries = {
            'max_attempts': 3,
            'mode': 'adaptive'
        }
    )

class Reviewer:
    def __init__(self, log_level=logging.INFO, client_id=None):
        self.log = logging.getLogger('codeguru-reviewer')
        self.log.setLevel(log_level)
        region = get_region()
        self.client_betav2 = boto3.client('codeguru-reviewer-betav2', endpoint_url=ENDPOINT_URL.format(aws_region=region), config=reviewer_config(region))
        self.client = boto3.client('codeguru-reviewer', config=reviewer_config(region))
        self.__update_user_agent(client_id)

    def __update_user_agent(self, client_id):
        if client_id:
            self.client.meta.config.user_agent += f' {client_id} '
            self.client_betav2.meta.config.user_agent += f' {client_id} '

    def __associate_repository(self, name, bucket_name, kms_key_id=''):
        """
        Associates a repository using the given name.
        Does not add tags to the association.
        """
        input_repository = {
            'S3Bucket':
            {
                'Name': name
            }
        }

        if kms_key_id:
            kms_details = {
                'KMSKeyId': kms_key_id,
                'EncryptionOption': 'CUSTOMER_MANAGED_CMK'
            }
        else:
            kms_details = {
                'EncryptionOption': 'AWS_OWNED_CMK'
            }

        if bucket_name:
            input_repository['S3Bucket']['BucketName'] = bucket_name

        associate_response = self.client_betav2.associate_repository(
            Repository=input_repository,
            ClientRequestToken= str(uuid.uuid4()),
            KMSKeyDetails=kms_details
        )

        association_arn = associate_response['RepositoryAssociation']['AssociationArn']
        self.log.info(f"Association ARN = {association_arn}")
        max_attempts = 10
        attempts = 0
        try:
            while attempts < max_attempts:
                attempts += 1
                describe_association = self.client_betav2.describe_repository_association(
                    AssociationArn=association_arn
                )
                association_result = describe_association.get('RepositoryAssociation', {})
                association_state = association_result['State']
                self.log.info(f"Association State = {association_state}")
                if association_state == 'Associated':
                    break
                elif association_state == 'Failed':
                    self.log.error("Association did not complete successfully")
                else:
                    time.sleep(20)
        except RuntimeError as e:
            self.log.exception("Exception occurred while associating a repository")
            raise e

        # try:
        #     association_complete_waiter = self.client_betav2.get_waiter('RepositoryAssociationSucceeded')
        #     association_complete_waiter.wait(AssociationArn=association_arn)
        #     self.log.debug(f"Association with arn={association_arn} moved to completed state")
        # except WaiterError as e:
        #     if "Max attempts exceeded" in e.message:
        #         self.log.error("Association did not complete successfully")
        #     else:
        #         self.log.exception("Exception occurred while associating a repository")
        #     raise e
        return association_arn

    def __get_associated_s3bucket(self, association_arn):
        """
        Returns the S3 Bucket related to the association identified by the
        input association_arn. 
        Expects the association to be in 'Associated' state.
        """
        describe_association = self.client_betav2.describe_repository_association(
            AssociationArn=association_arn
        )
        association_details = describe_association.get('RepositoryAssociation', {})
        if association_details.get('State') != 'Associated':
            self.log.info("Repository Association found to be in unexpected state for {}", association_arn)
            raise RuntimeError("Unexpected Issue! Please reach out to AWS Customer Support")

        s3_repository_details = association_details.get('S3RepositoryDetails', {})
        self.log.debug(f"S3 Repository details {s3_repository_details}")
        return s3_repository_details.get('BucketName')

    def __find_matching_associations(self, name):
        response = self.client_betav2.list_repository_associations(
            ProviderTypes=['S3Bucket'],
            States=['Associated'],
            Names=[name]
        )

        if response['RepositoryAssociationSummaries']:
            for association in response['RepositoryAssociationSummaries']:
                if association['Name'] == name:
                    return [association]

        return []

    def create_or_get_s3_association(self, name, bucket_name, kms_key_id=''):
        """
           Creates a new `S3Bucket` association with name if does not exist, 
           else returns matching association
        """
        association_arn = None

        existing_associations = self.__find_matching_associations(name)
        if not existing_associations:
            self.log.info(f"No existing associations found for {name}, creating a new one")
            association_arn = self.__associate_repository(name, bucket_name, kms_key_id)
        else:
            association_arn = existing_associations[0].get('AssociationArn')
            self.log.info(f"Found an existing association for {name} with {association_arn}")
        
        if not association_arn:
            self.log.error("Unexpected issue with fetching associations")
            raise RuntimeError("Unexpected Issue! Please reach out to AWS Customer Support")
        
        s3_bucket = self.__get_associated_s3bucket(association_arn)
        self.log.info(f"S3 Bucket obtained for the association with name {name}")
        return S3RepositoryAssociation(name=name, association_arn=association_arn, s3_bucket=s3_bucket)


    def __create_code_review(self, code_review_request):
        """
            Creates a code review job with source & build artifacts in S3 given an
            existing association identified by `association_arn`
        """
        self.log.debug(f"Creating code review job with name: {code_review_request.name}")

        create_cr_response = self.client_betav2.create_code_review(
            Name=code_review_request.name,
            RepositoryAssociationArn=code_review_request.association_arn,
            ClientRequestToken=str(uuid.uuid4()),
            Type={
                'RepositoryAnalysis': {
                    'SourceCodeType': code_review_request.get_source_code_type()
                },
                'AnalysisTypes': code_review_request.get_analysis_types()
            }
        )

        code_review_dict = create_cr_response.get('CodeReview', {})
        code_review_arn = code_review_dict.get('CodeReviewArn')
        self.log.info(f"CodeReview created with arn={code_review_arn} for job={code_review_request.name}")

        max_attempts = 20
        attempts = 0
        try:
            while attempts < max_attempts:
                attempts += 1
                code_review_response = self.describe_code_review(code_review_arn)
                cr_state = code_review_response["CodeReview"]["State"]
                self.log.info(f"CodeReview Job response = {cr_state}")
                if cr_state == 'Completed':
                    break
                elif cr_state == 'Failed':
                    self.log.error("CodeReview did not complete successfully")
                else:
                    time.sleep(30)
        except RuntimeError as e:
            self.log.exception("Exception occurred in waiting for code review to succeed")
            raise e
        # try:
        #     code_review_complete_waiter = self.client_betav2.get_waiter('CodeReviewCompleted')
        #     code_review_complete_waiter.wait(CodeReviewArn=code_review_arn)
        #     self.log.debug(f"CodeReview job with arn={code_review_arn} was completed")
        # except WaiterError as e:
        #     if "Max attempts exceeded" in e.message:
        #         self.log.error("CodeReview did not complete successfully")
        #     else:
        #         self.log.exception("Exception occurred in waiting for code review to succeed")
        #     raise e
        return code_review_arn

    def describe_code_review(self, code_review_arn):
        self.log.info(f"Describe code review job with arn: {code_review_arn}")

        return self.client_betav2.describe_code_review(CodeReviewArn=code_review_arn)


    def __list_recommendations(self, code_review_arn):
        """
            List recommendations for a given code review (`code_review_arn`).
        """
        recommendations = []
        next_token = None
        attempts = 0
        while True:
            attempts += 1
            list_recommendations_response = self.client_betav2.list_recommendations(
                CodeReviewArn=code_review_arn, 
                NextToken=next_token) if next_token else self.client_betav2.list_recommendations(CodeReviewArn=code_review_arn)

            next_token = list_recommendations_response.get('NextToken')
            recommendations.extend(list_recommendations_response.get('RecommendationSummaries', []))
            # self.log.debug(f"Obtained {len(recommendations.get('RecommendationSummaries', []))} after {attempts} attempts so far ")
            if next_token is None:
                break
        recos = {}
        recos['RecommendationSummaries'] = recommendations
        return recos
    
    def trigger_code_review(self, code_review_request):
        """
           Triggers a new code review job and returns the list of recommendations
        """
        code_review_arn = self.__create_code_review(code_review_request)
        recommendations = self.__list_recommendations(code_review_arn)
        return recommendations
