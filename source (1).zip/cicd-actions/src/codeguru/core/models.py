import uuid

class S3RepositoryAssociation:
    def __init__(self, name, association_arn, s3_bucket):
        """
        An associated S3Bucket Repository association.
        """
        self.__name = name
        self.__association_arn = association_arn
        self.__s3_bucket = s3_bucket

    @property
    def name(self):
        return self.__name

    @property
    def association_arn(self):
        return self.__association_arn

    @property
    def s3_bucket(self):
        return self.__s3_bucket

    def __eq__(self, other):
        if isinstance(other, S3RepositoryAssociation):
             return self.name == other.name \
                    and self.association_arn == other.association_arn \
                    and self.s3_bucket == other.s3_bucket
        return False

class RequestMetadata:

    def __init__(self, request_id=None, requester=None, event_type=None):
        """
        :type request_id str
        :param request_id An identifier for the request. Could be pull request id, push event id

        :type requester str
        :param requester Entity requesting the code review request

        :type event_type dict
        :param event_type Metadata object for the type of the event
        """

        self.request_id = request_id
        self.requester = requester
        self.event_type = event_type

    @property
    def request_metadata(self):
        request_metadata_dict = {}
        if self.request_id:
            request_metadata_dict['RequestId'] = self.request_id

        if self.requester:
            request_metadata_dict['Requester'] = self.requester

        if self.event_type:
            request_metadata_dict['EventType'] = self.event_type

        return request_metadata_dict if request_metadata_dict else None

class CodeReviewRequest:

    def __init__(self, s3_association, src_s3key,
               build_s3key=None,  before_commit=None, after_commit=None,
               source_branch=None, destination_branch=None,
               merge_commit=None, request_context=None):
        if not isinstance(s3_association, S3RepositoryAssociation):
            raise TypeError(f"Expected {s3_association} of type S3RepositoryAssociation")
        self.s3_association = s3_association
        self.src_artifacts_s3key = src_s3key
        self.build_artifacts_s3key = build_s3key
        self.before_sha = before_commit
        self.after_sha = after_commit
        self.merge_sha = merge_commit
        self.request_context = request_context
        self.source_branch = source_branch
        self.destination_branch = destination_branch

    def __s3_repository_details(self):
        code_artifacts_dict = {
            'SourceCodeArtifactsObjectKey': self.src_artifacts_s3key,
        }
        if self.build_artifacts_s3key:
            code_artifacts_dict['BuildArtifactsObjectKey'] = self.build_artifacts_s3key
        return {
            'Name': self.s3_association.name,
            'Details': {
                'BucketName': self.s3_association.s3_bucket,
                'CodeArtifacts': code_artifacts_dict
            }
        }

    def __commit_diff(self):
        commit_diff = {}
        if self.after_sha or self.before_sha: # both are required if provided
            commit_diff['DestinationCommit'] = self.before_sha
            commit_diff['SourceCommit'] = self.after_sha
        if self.merge_sha:
            commit_diff['MergeBaseCommit'] = self.merge_sha

        return commit_diff if commit_diff else None

    def __repository_head(self):
        repo_head = {}

        if self.destination_branch:
            repo_head['BranchName'] = self.destination_branch.replace("refs/heads/", "")

        return repo_head if repo_head else None

    def __branch_diff(self):
        branch_diff = {}
        if self.source_branch or self.destination_branch: # both are required if provided
            branch_diff['SourceBranchName'] = self.source_branch
            branch_diff['DestinationBranchName'] = self.destination_branch

        return branch_diff if branch_diff else None

    @property
    def association_arn(self):
        return self.s3_association.association_arn

    @property
    def name(self):
        name = self.s3_association.name
        u_id = str(uuid.uuid4()).upper().replace("-", "")
        cr_job_name = f"{name.upper()}-{u_id[0:6]}"
        return cr_job_name

    def get_source_code_type(self):
        source_code_type =  {'S3BucketRepository': self.__s3_repository_details()}
        commit_diff = self.__commit_diff()
        repository_head = self.__repository_head()
        branch_diff = self.__branch_diff()
        if commit_diff:
            source_code_type['CommitDiff'] = commit_diff
        if branch_diff:
            source_code_type['BranchDiff'] = branch_diff
        if repository_head:
            source_code_type['RepositoryHead'] = repository_head
        if isinstance(self.request_context, RequestMetadata):
            request_metadata = self.request_context.request_metadata
            if request_metadata:
                source_code_type['RequestMetadata'] = request_metadata
        return source_code_type

    def get_analysis_types(self):
        return ['CodeQuality', 'Security'] if self.build_artifacts_s3key else ['CodeQuality']
