import os
import boto3
import logging

FALLBACK_REGION = "us-west-2"

def configure_aws_region(region_arg=None):
    # use region_helper to detect, fall back to aws_region as last resort
    aws_region_detected = __detect_region()
    if aws_region_detected:
        logging.info(f"Detected AWS Region: {aws_region_detected}")
    
    # override aws region if supplied and region could not be detected
    aws_region = aws_region_detected if aws_region_detected else region_arg
    if aws_region_detected is None and region_arg is None:
        logging.info(f"Falling back to region {FALLBACK_REGION}")
        aws_region = FALLBACK_REGION

    os.environ['AWS_REGION'] = aws_region # initialize as environment variable to use everywhere.
    return aws_region

def __detect_region():
    """
    Dynamically determine the region if not supplied.
    """
    easy_checks = [
        # check if set through ENV vars
        os.environ.get('AWS_REGION'),
        os.environ.get('AWS_DEFAULT_REGION'),
        # else check if set in config or in boto already
        boto3.DEFAULT_SESSION.region_name if boto3.DEFAULT_SESSION else None,
        boto3.Session().region_name,
    ]
    for region in easy_checks:
        if region:
            return region

def get_region():
    """
    Returns configured aws region.
    """
    if os.environ.get('AWS_REGION') is None:
        raise RuntimeError(f"Cannot proceed with missing region configuration!")

    return os.environ['AWS_REGION']
