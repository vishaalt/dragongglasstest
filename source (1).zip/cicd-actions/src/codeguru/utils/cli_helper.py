import os
import argparse
import re
import sys

class ReadableDirectory(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        prospective_dir=values
        print(f"{os.path} current os path")
        # if not os.path.isdir(prospective_dir):
        #     print(f"{prospective_dir} is not a valid path")
        #     sys.exit(-1)
        if os.access(prospective_dir, os.R_OK):
            setattr(namespace,self.dest,prospective_dir)
        else:
            print(f"{prospective_dir} is not readable")
            sys.exit(-1)

def kms_key_id_regex_type(arg_value, pattern=re.compile(r"[a-zA-Z0-9-]+")):
#     if not pattern.match(arg_value):
#         print(f"KMS Key ID: {arg_value} is not valid")
#         sys.exit(-1)
    return arg_value

def clean_up(*args):
    for filename in args:
        if filename and os.path.exists(filename):
            os.remove(filename)
