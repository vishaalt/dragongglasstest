import os
import sys
import threading
import logging
import boto3
from boto3.s3.transfer import TransferConfig
from utils import region_helper

MB = 1024 ** 2

class ProgressPercentage:

    def __init__(self, filename):
        self._filename = filename
        self._size = float(os.path.getsize(filename))
        self._seen_so_far = 0
        self._lock = threading.Lock()

    def __call__(self, bytes_amount):
        # To simplify, assume this is hooked up to a single filename
        with self._lock:
            self._seen_so_far += bytes_amount
            percentage = (self._seen_so_far / self._size) * 100
            logging.info("\r%s  %s / %s  (%.2f%%)" % (self._filename, self._seen_so_far, self._size, percentage))


def upload_archive(s3_bucket, s3_prefix, archive_path):
    """
      Uploads archive to s3 bucket `s3_bucket` under the given key `s3_key`.
    """
    if not os.path.exists(archive_path):
        raise FileNotFoundError(f"Archive {archive_path} not found")
    s3 = boto3.resource('s3', region_name=region_helper.get_region())
    bucket = s3.Bucket(s3_bucket)
    config = TransferConfig(multipart_threshold=10*MB, max_concurrency=5) # Set the desired multipart threshold value (5MB)
    s3_archive_path = f'{s3_prefix}/{os.path.basename(archive_path)}'
    bucket.upload_file(archive_path, s3_archive_path, Config=config, Callback=ProgressPercentage(archive_path))
    logging.info(f"S3 Upload of {archive_path} completed")
    logging.info(f"Archive {archive_path} removed")
    return s3_archive_path
