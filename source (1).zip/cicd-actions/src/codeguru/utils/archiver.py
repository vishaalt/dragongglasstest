import os
import logging
import glob
import zipfile
import re



def zip(src, archive_name, file_regex=".*", junk_paths=False):
    """
     Compress a file/directory into zip file.
     Ignores absolute paths if junk_paths is True.
     Filters files matching file_regex to include in archive.
    """
    # src_path = os.path.abspath(src)
    src_path = src
    # logging.debug(f"Archiving source found at {src_path}")
    # if not os.path.exists(src_path):
    #     raise FileNotFoundError(f"File/Directory {src} does not exist")

    zip_name = os.path.abspath(f"{archive_name}.zip") if not re.compile(".*[.]zip$").match(archive_name) else archive_name

    total_size = 0
    zfile = zipfile.ZipFile(zip_name, "w", zipfile.ZIP_DEFLATED)
    regex = re.compile(file_regex)

    for root, directories, files in os.walk(src_path):
        for filename in files:
            if regex.match(filename):
                filepath = os.path.join(root, filename)
                absname = os.path.abspath(filepath)
                arcname = filename if junk_paths else absname
                logging.debug('zipping %s as %s' % (absname, arcname))
                total_size += os.path.getsize(filepath)
                zfile.write(absname, arcname)

    zfile.close()
    logging.info(f"Compressed {src}, before: {total_size} after: {os.path.getsize(zfile.filename)}")
    return os.path.abspath(zip_name)


def zipdir(path, ziph, file_regex=".*"):
    regex = re.compile(file_regex)

    # ziph is zipfile handle
    for root, dirs, files in os.walk(path):
        for file in files:
            if regex.match(file):
                ziph.write(os.path.join(root, file))
